﻿Imports Microsoft.Win32.TaskScheduler

Module TaskManager

    Public connMIS As ADODB.Connection

    Sub Main()

        Dim strPcName As String
        Dim strSql As String
        Dim bIsWeekday As Boolean
        Dim strCmd As String
        Dim rsData As ADODB.Recordset
        Dim dStart As Date
        Dim dEnd As Date
        Dim ii As Integer
        Dim iStep As Integer
        Dim iStart As Integer
        Dim iEnd As Integer
        Dim iDayWeek As Integer
        Dim dStartTime As Date
        Dim id_string As String = "volarb_task"
        Dim id As Integer
        Dim runAsUser As String

        id = 1
        strPcName = Trim(Environ("COMPUTERNAME"))
        If strPcName = "NY9-WSQL1" Then
            runAsUser = "server"
        Else
            runAsUser = "pc"
        End If
        ' Clear all old at jobs
        strCmd = "schtasks /Delete /TN * /F"
        'ShellWait(strCmd)
        'Shell(strCmd, , True)

        'http://taskscheduler.codeplex.com
        Using ts As New TaskService()
            For Each task As Task In ts.RootFolder.Tasks
                If task.Name.Contains("volarb_task") Then
                    ts.RootFolder.DeleteTask(task.Name)
                End If
            Next
        End Using

        ' Today a weekday
        iDayWeek = Weekday(Today)
        If iDayWeek >= 2 And iDayWeek <= 6 Then
            ' Today is a weekday
            bIsWeekday = True
        Else
            bIsWeekday = False
        End If

        strSql = "select * " & _
                 "from task_sched s " & _
                "inner join task_task t on s.id_task = t.id_task " & _
                "inner join task_pc p on p.id_pc = s.id_pc " & _
                "and enabled = 1 " & _
                "and pc_name = '" & strPcName & "' " & _
                "order by task_start_time"
        rsData = ExecuteSQL(strSql, connMIS)

        If Not rsData.EOF Then
            While Not rsData.EOF

                If (rsData("weekday").Value = 0 And bIsWeekday) Or _
                    (rsData("weekday").Value = -1) Or _
                    (rsData("weekday").Value = iDayWeek) Then
                    ' Weekday we want to run or
                    ' don't care on weekday (any day)
                    ' or specific day Sun=1,Mon=2,Tue=3,Wed=4,Thu=5,Fri=6,Sat=7
                    If (rsData("task_end_time").Value.Equals(System.DBNull.Value)) Then
                        ' This is the one time case

                        'strCmd = "C:\Windows\System32\at " & Hour(rsData("task_start_time").Value) & ":" & Minute(rsData("task_start_time").Value) & "0 /interactive /next:" & Day(Today) & " " & rsData("task_path").Value & ""
                        'strCmd = "C:\Windows\System32\at " & rsData("task_start_time").Value.hour & ":" & rsData("task_start_time").Value.minute & " /interactive /next:" & Day(Today) & " """ & rsData("task_path").Value & """"
                        If runAsUser = "server" Then
                            If rsData("id_sched").Value = 153 Then 'tasks run only when user is logged on
                                strCmd = "schtasks /create /IT /RL HIGHEST /F /RU walleyetrading\schan /sc ONCE /st " & Format(rsData("task_start_time").Value, "HH") & ":" & Format(rsData("task_start_time").Value, "mm") & " /tr " & """" & rsData("task_path").Value & """" & " /tn " & id_string & id
                            Else
                                strCmd = "schtasks /create /RL HIGHEST /F /RU walleyetrading\schan /RP Newuser1 /sc ONCE /st " & Format(rsData("task_start_time").Value, "HH") & ":" & Format(rsData("task_start_time").Value, "mm") & " /tr " & """" & rsData("task_path").Value & """" & " /tn " & id_string & id
                            End If
                        Else
                            strCmd = "schtasks /create /F " & " /sc ONCE /st " & Format(rsData("task_start_time").Value, "HH") & ":" & Format(rsData("task_start_time").Value, "mm") & " /tr " & """" & rsData("task_path").Value & """" & " /tn " & id_string & id
                        End If
                            dStartTime = Format(Today, "dd MMM yyyy") & " " & rsData("task_start_time").Value.hour & ":" & Format$(Minute(TimeSerial(0, rsData("task_start_time").Value.minute, 0)), "00") & ":00"

                            If dStartTime >= Now() Then
                                'ShellWait(strCmd)
                                Shell(strCmd, , True)
                                id = id + 1
                            End If
                        Else
                            ' Else we want to run multiple times per day
                            dStart = rsData("task_start_time").Value
                            dEnd = rsData("task_end_time").Value
                            If rsData("task_end_time") Is Nothing Then
                                'MsgBox("Default time for mins can't be null for :" & rsData("task_desc"))
                            Else
                                iStep = rsData("task_step_mins").Value
                            End If

                            iStart = Hour(dStart) * 60 + Minute(dStart)
                            iEnd = Hour(dEnd) * 60 + Minute(dEnd)
                            For ii = iStart To iEnd Step iStep
                                'strCmd = "C:\Windows\System32\at " & FormatMin(ii) & " /interactive /next:" & Day(Today) & " """ & rsData("task_path").Value & """"
                                If runAsUser = "server" Then
                                    strCmd = "schtasks /create /RL HIGHEST /F /RU walleyetrading\schan /RP Newuser1 /sc ONCE /st " & FormatMin(ii) & " /tr " & """" & rsData("task_path").Value & """" & " /tn " & id_string & id
                                Else
                                    strCmd = "schtasks /create /F /sc ONCE /st " & FormatMin(ii) & " /tr " & """" & rsData("task_path").Value & """" & " /tn " & id_string & id
                                End If
                                dStartTime = Format(Today, "dd MMM yyyy") & " " & FormatMin(ii) & ":00"
                                If dStartTime >= Now() Then
                                    Shell(strCmd, , True)
                                    id = id + 1
                                End If
                            Next
                        End If
                    End If
                    rsData.MoveNext()
            End While
        End If

        DisconnectDatabases()

    End Sub

    Public Function FormatMin(ByVal iMin As Integer) As String
        FormatMin = Format$(Hour(TimeSerial(0, iMin, 0)), "00") & ":" & _
                    Format$(Minute(TimeSerial(0, iMin, 0)), "00")
    End Function


    Public Function ExecuteSQL(ByVal strSql As String, _
                               ByVal connSql As ADODB.Connection, _
                               Optional ByVal lngRecordsChanged As Long = 0, _
                               Optional ByVal bUpdateStaus As Boolean = False) As ADODB.Recordset

        Dim rsData As ADODB.Recordset

        If (connSql Is Nothing) Then
            connSql = New ADODB.Connection
            'connMIS.CursorLocation = adUseClient
            'connMIS.CommandTimeout = 1200000
            connSql.ConnectionString = "ODBC;DATABASE=MIS;UID=volarb;PWD=el3phant;DSN=MIS"
            connSql.Open()
        End If

        On Error Resume Next
        'DoEvents()

        rsData = connSql.Execute(strSql)
        If Err.Number <> 0 Then
            MsgBox("Unable to execute SQL: " & vbNewLine & _
                     Err.Description & " " & vbNewLine & _
                     strSql)
            End
        End If
        On Error GoTo 0


        ExecuteSQL = rsData

    End Function


    Public Sub DisconnectDatabases()
        connMIS = Nothing
    End Sub

    Public Sub ConnectToMIS()
        connMIS = New ADODB.Connection
        'connMIS.CursorLocation = adUseClient
        'connMIS.CommandTimeout = 1200000
        connMIS.ConnectionString = "ODBC;DATABASE=MIS;UID=volarb;PWD=el3phant;DSN=MIS"
        connMIS.Open()
    End Sub

End Module